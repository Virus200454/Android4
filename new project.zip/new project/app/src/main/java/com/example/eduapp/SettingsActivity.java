package com.example.eduapp;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private RadioGroup rgLanguage, rgTextSize;
    private RadioButton rbEnglish, rbArabic, rbSmall, rbMedium, rbLarge;
    private Button btnApply;
    private PreferenceManager preferenceManager;

    @Override
    protected void attachBaseContext(Context newBase) {
        PreferenceManager pref = new PreferenceManager(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, pref.getLanguage()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        preferenceManager = new PreferenceManager(this);

        rgLanguage = findViewById(R.id.rgLanguage);
        rgTextSize = findViewById(R.id.rgTextSize);

        rbEnglish = findViewById(R.id.rbEnglish);
        rbArabic = findViewById(R.id.rbArabic);

        rbSmall = findViewById(R.id.rbSmall);
        rbMedium = findViewById(R.id.rbMedium);
        rbLarge = findViewById(R.id.rbLarge);

        btnApply = findViewById(R.id.btnApply);

        loadCurrentPreferences();

        btnApply.setOnClickListener(v -> {
            savePreferences();
            setResult(RESULT_OK);
            finish();
        });
    }

    private void loadCurrentPreferences() {
        if (preferenceManager.getLanguage().equals("en")) {
            rbEnglish.setChecked(true);
        } else {
            rbArabic.setChecked(true);
        }

        String size = preferenceManager.getTextSize();
        if (size.equals("Small")) rbSmall.setChecked(true);
        else if (size.equals("Large")) rbLarge.setChecked(true);
        else rbMedium.setChecked(true);
    }

    private void savePreferences() {
        if (rbEnglish.isChecked()) {
            preferenceManager.setLanguage("en");
        } else {
            preferenceManager.setLanguage("ar");
        }

        if (rbSmall.isChecked()) {
            preferenceManager.setTextSize("Small");
        } else if (rbLarge.isChecked()) {
            preferenceManager.setTextSize("Large");
        } else {
            preferenceManager.setTextSize("Medium");
        }
    }
}
