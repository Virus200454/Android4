package com.example.eduapp;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static final String PREF_NAME = "EduAppPrefs";
    private static final String KEY_LANGUAGE = "language";
    private static final String KEY_TEXT_SIZE = "text_size";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public PreferenceManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void setLanguage(String lang) {
        editor.putString(KEY_LANGUAGE, lang);
        editor.apply();
    }

    public String getLanguage() {
        return sharedPreferences.getString(KEY_LANGUAGE, "en"); // Default is English
    }

    public void setTextSize(String size) {
        editor.putString(KEY_TEXT_SIZE, size);
        editor.apply();
    }

    public String getTextSize() {
        return sharedPreferences.getString(KEY_TEXT_SIZE, "Medium"); // Default is Medium
    }
}
