package com.example.eduapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    private TextView tvTitle;
    private TextView tvContent1, tvContent2, tvContent3;
    private Button btnSettings;
    private PreferenceManager preferenceManager;

     private final ActivityResultLauncher<Intent> settingsLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            preferenceManager = new PreferenceManager(this);
                            applyPreferences();
                            recreate(); // لتحديث اللغة
                        }
                    }
            );

    @Override
    protected void attachBaseContext(Context newBase) {
        PreferenceManager pref = new PreferenceManager(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, pref.getLanguage()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferenceManager = new PreferenceManager(this);

        tvTitle = findViewById(R.id.tvTitle);
        tvContent1 = findViewById(R.id.tvContent1);
        tvContent2 = findViewById(R.id.tvContent2);
        tvContent3 = findViewById(R.id.tvContent3);
        btnSettings = findViewById(R.id.btnSettings);
        CardView card1 = findViewById(R.id.card1);
        CardView card2 = findViewById(R.id.card2);
        CardView card3 = findViewById(R.id.card3);

        addCardAnimation(card1);
        addCardAnimation(card2);
        addCardAnimation(card3);

        applyPreferences();

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            settingsLauncher.launch(intent);
        });
    }

    private void applyPreferences() {
        String textSize = preferenceManager.getTextSize();
        float sizeInSp;

        switch (textSize) {
            case "Small":
                sizeInSp = 14f;
                break;
            case "Large":
                sizeInSp = 24f;
                break;
            case "Medium":
            default:
                sizeInSp = 18f;
                break;
        }

        tvContent1.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeInSp);
        tvContent2.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeInSp);
        tvContent3.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeInSp);
    }
    private void addCardAnimation(View card) {
        card.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(120).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP ||
                    event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
            return false;
        });
    }

}
